let app = require('./app/config/server'); //carregando o módulo
let rotaHome = require('./app/routes/home'); //definindo
rotaHome(app); //executando

let rotaCursos = require('./app/routes/cursos');
rotaCursos(app);

let rotaHistoria = require('./app/routes/historia');
rotaHistoria(app); 

let rotaProfessores = require('./app/routes/professores');
rotaProfessores(app);

let rotaAdicionarUsuario = require('./app/routes/adicionar_usuario');
rotaAdicionarUsuario(app);

app.listen(3000, function() {
    console.log("Servidor iniciado");
});